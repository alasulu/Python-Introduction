#Integers
x = 14
print(x)
print(type(x))

#Floats
nearly_pi = 3.141592653589793238462643383279502884197169399375105820974944
print(nearly_pi)
print(type(nearly_pi))
almost_pi = 22/7
print(almost_pi)
print(type(almost_pi))
rounded_pi = round(almost_pi,5) #Rounding the 5 decimal places
print(rounded_pi)
print(type(rounded_pi))
y_float = 1. #It does not have any fraction but "." attributes to value as float value
print(y_float)
print(type(y_float))

#Booleans
z_one = True
print(z_one)
print(type(z_one))
z_two = False
print(z_two)
print(type(z_two))
z_three = (1<2)
print(z_three)
print(type(z_three))
z_four = (2>5)
print(z_four)
print(type(z_four))
z_five = not z_one
print(z_five)
print(type(z_five))
z_six = not z_two
print(z_six)
print(type(z_six))

#Strings
w = 'Hello Python'
print(w)
print(type(w))
print(len(w)) #Note that the quotation marks are not included when calculating the length.
shortest_string = ""
print(len(shortest_string))
print(type(shortest_string))
my_number = '1.34569876'
print(type(my_number)) #If you put a number in quotation marks, it has a string data type.
print(len(my_number))
also_my_number = float(my_number) #If we have a string that is convertible to a float, 
#we can use float().
print(also_my_number)
print(type(also_my_number))
new_string = "abc" + "def"
print(new_string) #You can also add two strings. It results in a longer string that 
#combines the two original strings by concatenating them.
print(type(new_string))
print(len(new_string))
newest_string = "abc" * 3 #But you can multiply a string by an integer
print(newest_string)
print(type(newest_string))
print(len(newest_string))
#Note that you cannot multiply a string by a float! Trying to do so will return an error.
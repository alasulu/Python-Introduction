print('Hello World') ---Printing Code---

# Calculations #

print(2+3);   ---Addition---
print(9-5);   ---Subtraction---
print(1*4);   ---Multiplication---
print(72/8);  ---Division---
print(2**10); ---Exponential---
print((((2+5)**3)*1.5)/(86-81)); ---You can adjust calculations with extra brackets

# Variables #

test_var = 4+5 --Manipulating the Variables--
print(test_var);
my_var = (3**5)/3.14
print(my_var)
my_var = (13**2)/38
print(my_var)
my_var = (my_var + 5)/ test_var
print(my_var)

# Using Multiple Variables #

num_years = 2
days_per_year = 365
hours_per_day = 24
mins_per_hour = 60
secs_per_min = 60
total_secs = num_years * days_per_year * hours_per_day * mins_per_hour * secs_per_min
print(total_secs)
days_per_year = 366.5
total_secs = num_years * days_per_year * hours_per_day * mins_per_hour * secs_per_min
print(total_secs)
print(2>3)
print(2<3)
var_one = 1
var_two = 2
print(var_one < 1)
print(var_two >= 2)
# == equals
# != does not equal
# < less than
# <= less than or equal to 
# > greater than
# >= greater than or equal to 
var_one == 1
# var_one==1 checks if the value of var_one is 1, but
# var_one=1 sets the value of var_one to 1.
def evaluate_temp(temp):
    # Set an initial message
    message = "Normal temperature."
    # Update value of message only if temperature greater than 38
    if temp > 38:
        message = "Fever!"
    return message
print(evaluate_temp(37))
print(evaluate_temp(39.5))

def evaluate_temp_with_else(temp):
    if temp<38:
            message = 'Normal temperature.'
    else:
            message ='Fever'
    return message
print(evaluate_temp_with_else(35))
print(evaluate_temp_with_else(39))

def evaluate_temp_with_elif(temp):
    if temp>38:
        message = 'Fever'
    elif temp>35:
        message = 'Normal Temperature'
    else:
        message= 'Low Temperature'
    return message
print(evaluate_temp_with_elif(33))
print(evaluate_temp_with_elif(36.5))
print(evaluate_temp_with_elif(40))

def get_taxes(earnings):
    if earnings < 12000:
        tax_owed = .25 * earnings
    else:
        tax_owed = .30 * earnings
    return tax_owed
ana_taxes = get_taxes(15000)
bob_taxes = get_taxes(8000)
print(ana_taxes)
print(bob_taxes)

def add_three_or_eight(value):
    if value<10:
        value = value + 3
    else:
        value = value + 8
    return value
alasulu_value = add_three_or_eight(16)
emin_value = add_three_or_eight(7)
print(alasulu_value)
print(emin_value)

def get_dose(weight):
    if weight < 5.2:
        dose = 1.25
    elif weight < 7.9:
        dose = 2.5
    elif weight < 10.4:
        dose = 3.75
    elif weight < 15.9:
        dose = 5
    elif weight < 21.2:
        dose = 7.5
    else:
        dose = 10
    return dose
print(get_dose(4))
print(get_dose(6))
print(get_dose(9))
print(get_dose(13))
print(get_dose(17))
print(get_dose(25))

#Question 1
def get_grade(score):
    if 90<=score<=100:
         grade = "A"
    elif 80<=score<=89:
        grade = "B"
    elif 70<=score<=79:
        grade = "C"
    elif 60<=score<=69:
        grade = "D"
    else:
        grade = "F"
    return grade
serkan_score = 90
print(get_grade(serkan_score))
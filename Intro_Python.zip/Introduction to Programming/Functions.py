def add_three(input_var): #add_three is the name of our function, input_var is 
#function argument
    output_var = input_var + 3    
    return output_var #return is representing we are exiting from function
#output_var is the value when the function is exited

# How to run or call a function
new_number= add_three(10)
print(new_number) 

def get_pay(num_hours):
    pay_pretax = num_hours*15
    pay_aftertax = pay_pretax*(1-.12)
    return pay_aftertax

pay_fulltime = get_pay(40) #for 40 hours working
print(pay_fulltime)
pay_fulltime_2 = get_pay(32) # for 32 hours working
print(pay_fulltime_2)

def get_pay_with_more_inputs(num_hours, hourly_wage, tax_bracket):
    pay_pretax = num_hours*hourly_wage
    pay_aftertax = pay_pretax*(1-tax_bracket)
    return pay_aftertax
higher_pay_aftertax = get_pay_with_more_inputs(40,24, .22)
print(higher_pay_aftertax)
same_pay_fulltime = get_pay_with_more_inputs(40,15, .12)
print(same_pay_fulltime)

def print_hello():
    print("Hello, you")
    print("Good Morning!")
    
print_hello()